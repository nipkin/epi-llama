﻿define("epi-find/store/ServiceHealthStore", [
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/_base/declare",
    "dojo/store/util/QueryResults",
    "epi/shell/store/JsonRest",
    "epi-saas-base/RetryableXhrWrapper"
],
    function (lang, Deferred, declare, QueryResults, JsonRest, RetryableXhrWrapper) {
        return declare(JsonRest, {
            // summary:
            //      This is a basic store for RESTful communicating with Service Health

            constructor: function (options) {
                this.xhrHandler = new RetryableXhrWrapper(options ? options.handlerOptions : null);
                this.headers = { "Content-Type": "application/json" };
                declare.safeMixin(this, options);
            },

            query: function (options) {
                options = options || {};
                var headers = lang.mixin({ Accept: this.accepts }, this.headers, options.headers);
                results = this.xhrHandler.xhr("GET", {
                    url: this.target,
                    handleAs: "json",
                    headers: headers
                });

                var queryResults = new Deferred();
                results.then(function (data) {
                    queryResults.resolve(data);
                }, function (error) {
                    queryResults.reject(error);
                });

                queryResults.data = results.then(function (data) {
                    return data;
                });

                return QueryResults(queryResults);
            }
        });
    });
