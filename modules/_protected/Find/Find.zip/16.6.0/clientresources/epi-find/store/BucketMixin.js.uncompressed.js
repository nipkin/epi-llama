define("epi-find/store/BucketMixin", [
    "dojo/_base/declare",
    "dojo/date",
    "dojo/date/stamp",
    "dojo/when"
],
function (declare, date, stamp, when) {

    return declare([], {
        // summary:
        //      Bucket mixin to pad out empty intervals of requested result set with "0"

        // keyName: String
        //      Most commonly it will be a timestamp range that needs padding
        keyName: "timestamp",

        // keyName: String
        //      This mixin currently only supports one "value" per bucket and this is the key
        valueName: "count",

        query: function (query) {
            // summary:
            //      Queries the store for objects. After a query has returned the results from
            //      server, values need to be put into buckets to fill out any non-returned
            //      empty results.
            // query: String|Object|Function
            //      The query to use for retrieving objects from the store.
            if(!query || !query.to || !query.from || !query.interval) {
                return this.inherited(arguments);
            }

            var keyName = this.keyName,
                valueName = this.valueName;

            return when(this.inherited(arguments)).then(function (results) {
                var buckets = {},
                    to = stamp.fromISOString(query.to),
                    from = stamp.fromISOString(query.from),
                    interval = query.interval,
                    fromOffset = from.getTimezoneOffset();

                if(interval === "month") {
                    from.setUTCDate(1);
                    to.setUTCDate(1);
                }

                // create a bucket for every interval
                for (var i=0, j=date.difference(from, to, query.interval); i<j; i++) {
                    var curDate = date.add(from, interval, i);
                    curDate = date.add(curDate, "minute", fromOffset-curDate.getTimezoneOffset()); // Compensate offset for "i", needed if span has transitioned to DST
                    buckets[stamp.toISOString(curDate, {
                        zulu: true
                    })] = 0;
                }

                // populate buckets value from result
                for(var i2=0, j2=results.length; i2<j2; i2+=1) {
                    buckets[results[i2].timestamp] = results[i2][valueName];
                }

                var data = [];
                for (var key in buckets) {
                    var o = {};
                    o[keyName] = key;
                    o[valueName] = buckets[key];
                    data.push(o);
                }
                return data;
            });
        }
    });
});