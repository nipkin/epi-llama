﻿define("epi-find/Intents", [
    "dojo/_base/config"
],
    function (config) {
        // module:
        //      epi-find/Intents
        return {
            // summary:
            //      A plugin that configures all application intents.
            load: function (id, require, callback) {
                config.intents = {
                    view: {
                        dashboard: "dashboard",
                        synonyms: "optimize/synonyms",
                        bestBets: "optimize/bestbets",
                        relatedQueries: "optimize/relatedqueries",
                        autocomplete: "optimize/autocomplete",
                        connectors: "configure/connectors",
                        boosting: "configure/boosting",
                        index: "configure/index",
                        overview: "content/overview",
                        explore: "content/explore",
                        servicehealth: "servicehealth"
                    },

                    create: {
                        synonym: "optimize/synonyms",
                        bestbet: "optimize/bestbets",
                        relatedqueries: "optimize/relatedqueries"
                    }
                };
                callback();
            }
        };
    });