﻿define("epi-find/configure/BoostingPreviewModel", [
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/_base/config",
        "dojo/Stateful",

        "../util/search"
    ],
    function (declare,
              lang,
              config,
              Stateful,
              search) {

        return declare([Stateful], {
            // summary:
            //      View model for Boosting Search Preview widget.

            // searchText: String
            //      Search query text
            searchText: null,

            _searchTextSetter: function (value) {
                if (value !== this.searchText) {
                    this.searchText = value;
                    this.set("query", this._buildQuery());
                }
            },

            // language: String
            //      Language to filter search hits
            language: null,

            _languageSetter: function (value) {
                if (value !== this.language) {
                    this.language = value;
                    this.set("query", this._buildQuery());
                }
            },

            // bestBets: Boolean
            //      Indicates whether best bets should be used when searching
            bestBets: false,

            _bestBetsSetter: function (value) {
                value = !!value;
                if (value !== this.bestBets) {
                    this.bestBets = value;
                    this.set("query", this._buildQuery());
                }
            },

            // synonyms: Boolean
            //      Indicates whether synonyms should be used when searching
            synonyms: false,

            _synonymsSetter: function (value) {
                value = !!value;
                if (value !== this.synonyms) {
                    this.synonyms = value;
                    this.set("query", this._buildQuery());
                }
            },

            // weights: Object
            //      Unified search properties weights
            weights: null,

            _weightsSetter: function (value) {
                this.weights = value;
                this.set("query", this._buildQuery());
            },

            // query: Object
            //      Query that is used to run search
            query: null,

            _queryGetter: function () {
                if (!this.query) {
                    this.query = this._buildQuery();
                }
                return this.query;
            },

            // store: Store
            //      Elastic search store
            store: null,

            // languages: Array
            //      Array of available languages
            languages: null,

            _queryTemplate: {
                "query": null,
                "language": null,
                "apply_best_bets": false,
                "weights": { }
            },

            postscript: function() {
                this.inherited(arguments);
                if (!this.languages) {
                    this.languages = [];
                }
            },

            _buildQuery: function() {
                // summary:
                //      Builds ElasticSearch query based on model parameters.
                // tags:
                //      Private
                var query = lang.clone(this._queryTemplate);

                if (this.searchText) {
                    query.query = this.searchText;
                }

                if (this.language) {
                    query.language = this.language;
                }

                if (this.weights) {
                    query.weights = this.weights;
                }

                query.apply_best_bets = this.bestBets;
                query.apply_synonyms = this.synonyms;

                return query;
            }
        });
    });